#include "mcmini.h"

int main() {
  mc_choose(2);
  return 0;
}
