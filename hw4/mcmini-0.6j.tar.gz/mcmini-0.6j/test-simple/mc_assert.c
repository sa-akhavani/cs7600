#include <stdlib.h>
#include <assert.h>

int main() {
  assert(2+2 != 4);
  return 0;
}
